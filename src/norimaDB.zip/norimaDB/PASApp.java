package norimaDB;

import java.sql.SQLException;
import java.util.Scanner;

public class PASApp {

	public static void main(String[] args) throws SQLException {
		@SuppressWarnings("resource")
		Scanner  scan        = new Scanner(System.in);
		Customer customer    = new Customer();
		Policy   policy      = new Policy();
		Inquire  inquire     = new Inquire();
		Claim    claim       = new Claim();
		Create   create      = new Create();
		String optString = null;
		int option = 0;
		while(option != 8) {
			create.createTableCustomer();
			create.createTablePolicy();
			create.createTableHolder();
			create.createTableVehicle();
			create.createTableClaim();
			try {
				menuOption();
				optString = scan.nextLine();
				String strOptionString = optString.replaceAll("\\p{Cntrl}", "");
				System.out.print("==============================================================\n");
				if(optString.length() == 1) {
					option = Integer.valueOf(strOptionString);
					if (option > 0 && option < 9 ) {
						switch (option) {
							case 1: 
								customer.createAccount();
								break;
							case 2:
								policy.createPolicy();
								break;
							case 3:
								policy.cancelPolicy();
								break;
							case 4:
								claim.inquireClaim();
								break;
							case 5:
								inquire.inquireWithName();
								break;
							case 6:
								inquire.inquireWithPolicyNumber();
								break;
							case 7:
								inquire.inquireWithClaimNumber();
								break;
							default:
								break;
						}
					} else {
						System.out.println("\nPlease choose from the options only.\n");
					}
				} else {
					System.out.println("\nPlease choose from the options only.\n");
				}
			} catch (Exception e) {
				System.out.print("\n==============================================================\n");
				System.out.println("\nPlease choose from the options only.\n");
			}
		}
		System.out.println("\nExit session, program terminated...");
	}
	
	public static void menuOption() {
		System.out.println("==============================================================");
		System.out.println("|Automobile Insurance Policy and Claims Administration System|");
		System.out.println("|                       Options Menu                         |");
		System.out.println("|                                                            |");
		System.out.println("| 1. Create a new Customer Account                           |");
		System.out.println("| 2. Get a policy quote and buy the policy.                  |");
		System.out.println("| 3. Cancel a specific policy                                |");
		System.out.println("| 4. File an accident claim against a policy                 |");
		System.out.println("| 5. Search for a Customer account                           |");
		System.out.println("| 6. Search for and display a specific policy                |");
		System.out.println("| 7. Search for and display a specific claim                 |");
		System.out.println("| 8. Exit the PAS System                                     |");
		System.out.print  ("| Please enter option here: ");		
	}
 
}
