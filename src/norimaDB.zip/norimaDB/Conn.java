package norimaDB;

/**
 * 
 * @author DonAmbrocio
 * @Description : Assignment 3: Norima Java Developer Course Capstone Project Instruction(Supporting Class)
 * Created Date: 07/29/2022
 */

import java.sql.*;

public class Conn {

    static Connection conn = null;
    static String databaseName = "norima";
    static String dbUrl  = "jdbc:mysql://localhost:3306/" + databaseName;
    static String dbUser = "root";
    static String dbPass = "root";
    
    public static void dbConnect() throws SQLException {
            conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
    }
    
	public static void prepareStatement(String query) throws SQLException {
		dbConnect();
		PreparedStatement create = conn.prepareStatement(query);
		create.executeUpdate();
	}

	public static ResultSet createStatement(String query) throws SQLException {
		dbConnect();
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery(query);
		return rset;
	}
}