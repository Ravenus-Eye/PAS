package norimaDB;

import java.sql.*;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.Scanner;

public class Claim extends PolicyHolder {
	
	Inquire  inquire = new Inquire();
	Insert   insert  = new Insert();
	Select   select  = new Select();
	Validate valid   = new Validate();
	Scanner  scan    = new Scanner(System.in);
	private LocalDate accidentDate;
	private static LocalDate effectiveDate, expirationDate;
	private static String accidentLoc, accidentDesc, damageDesc;
	private double repairCost;
	
	public LocalDate getEffectiveDate() {
		return effectiveDate;
	}

	public void inquireClaim() throws ParseException, SQLException{
		try {
			Display display = new Display();
			String policyNumber = inquire.inquireWithPolicyNumber();
			if (policyNumber != null && !policyNumber.equalsIgnoreCase("q")) {
				System.out.println("\n**********************Claim Information***********************\n");
				Boolean active = enterAccidentDate(policyNumber);
				if (active) {
					accidentLoc  = enterString("Address where the accident happened\t: ", 30, 3);
					accidentDesc = enterString("Description of the accident\t\t: "      , 50, 3);
					damageDesc   = enterString("Description of damage to vehicle\t: "   , 50, 3);
					enterRepairCost();
					insert.insertClaim(policyNumber, accidentDate, accidentLoc, accidentDesc, damageDesc, repairCost);
					ResultSet rset = select.selectClaimWithPolicyNumber();
					System.out.println("\n************************Claim Created!************************\n");
					while (rset.next()) {
						display.display(rset.getString("claim_no"), policyNumber, accidentDate, accidentLoc, accidentDesc, damageDesc, repairCost);
					}
			    	Conn.conn.close();
					System.out.println("\n**************************************************************\n");
				}
			}
		} catch (Exception e) {
			System.out.print("");
		}
	}
	
	private void enterRepairCost() {
		boolean done = false;
		while (!done) {
			try {
				System.out.print("Estimated cost of repairs\t\t: ");
				String strCost = scan.nextLine();	
				if (strCost.equals("")) {
					System.out.println("Empty entry is unaccepted.");
				} else {
					Double rCost = Double.valueOf(strCost);
					if (rCost < 0) {
						System.out.println("Negative value is unaccepted.");
					} else if (rCost == 0) {
						System.out.println("Zero is unaccepted.");
					} else {
						this.repairCost = rCost;
						done = true;
					}
				}
			} catch (Exception e) {
				System.out.println("Invalid input.");
			}
		}
	}

	private boolean enterAccidentDate(String policyNum) throws NumberFormatException, SQLException, ParseException {
		PolicyHolder pHolder = new PolicyHolder();
		String effDate = null, expDate = null;
		boolean done = false;
		ResultSet rset  = select.selectPolicy(Integer.valueOf(policyNum));
		while (rset.next()) {
			effDate = rset.getString("effective_date");
			expDate = rset.getString("expiration_date");
		}
    	Conn.conn.close();
		effectiveDate  = LocalDate.parse(effDate);
		expirationDate = LocalDate.parse(expDate);
		if (expirationDate.compareTo(LocalDate.now()) < 0) {
			System.out.println(" You cannot use this policy anymore, it has already expired on "
					+ expirationDate.getMonth() + " " + expirationDate.getDayOfMonth() + ", " 
					+ expirationDate.getYear() + ".\n");
		} else if (effectiveDate.compareTo(LocalDate.now()) <= 0) {
			accidentDate = pHolder.enterDate("Date of accident(yyyy-MM-dd)\t\t: ", 4);
			done = true;
		} else {
			System.out.println(" You cannot use an inactive policy yet, it will be available on "
					+ effectiveDate.getMonth() + " " + effectiveDate.getDayOfMonth() + ", " 
					+ effectiveDate.getYear() + ".\n");
		}
		return done;
	}
}