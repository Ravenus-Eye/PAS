package norimaDB;

import java.util.Scanner;


import java.sql.*;

public class Customer extends PolicyHolder{

	Scanner scan   = new Scanner(System.in);
	Validate valid = new Validate();
	
	public void createAccount() throws SQLException {
		Search search = new Search();
		Insert insert = new Insert();
		System.out.print("\n******************New Customer Information******************\n\n");
		firstName = enterString("First Name\t\t : ", 20, 1);
		lastName  = enterString("Last Name\t\t : " , 20, 2);
		address   = enterString("Address\t\t\t : " , 40, 3);
		String accountNumber = search.searchAccount(firstName,lastName);
		if (accountNumber == null) {
			insert.insertCustomer(firstName, lastName, address);
			System.out.println("\n*********************************************************************");
			System.out.println("*                          Account Created!                         *");
			System.out.println("*********************************************************************");
			accountNumber = search.searchAccount(firstName,lastName);
			search.searchAccountPolicyNumber(accountNumber, 1);
			System.out.println("  Thank you for signing up to our service! ^_^\n");
		} else {
			search.searchAccountPolicyNumber(accountNumber, 1);
			System.out.println("Name already exist. Please check if this is your account.");
			System.out.println("If not, please use another name.\n");
			String  option = "";
			while (!option.equalsIgnoreCase("y") && !option.equalsIgnoreCase("n")) {
				System.out.print("Do you want to continue creating a new account? (y/n): ");
				option = scan.nextLine();
			}
			if (option.equalsIgnoreCase("y")) {
				createAccount();
			} else {
				System.out.println("\n Account creation aborted...\n");
			}
		}
	}	
}
