package norimaDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

public class Inquire extends Search {

	Scanner scan = new Scanner(System.in);
	
	public void inquireWithName() throws SQLException {
		System.out.println("\n\n************************Search by Name*************************");
		PolicyHolder pHolder = new PolicyHolder();
		System.out.println("Please enter the following information.\n");
		String firstName = pHolder.enterString("First Name\t\t : ", 20, 1);
		String lastName  = pHolder.enterString("Last Name\t\t : " , 20, 2);
		String accountNumber = searchAccount(firstName, lastName);
		if (accountNumber == null) {
			System.out.println("=====================================================================");
			System.out.println("|                          Account Details                          |");
			System.out.println("=====================================================================");
			System.out.format("%-10s%-20s%-20s%-20s", "Acct No.", "First Name", "Last Name", "Address");
			System.out.println("\n=====================================================================");
			System.out.println("\n No record found...");;
			System.out.println("=====================================================================\n");
		} else {
			searchAccountPolicyNumber(accountNumber, 1);
		}
	}

	public String inquireWithPolicyNumber() throws SQLException, ParseException {
		String policyNumber  = inquirePolicy("\n\n******************Search by Policy Number*********************");
		if (policyNumber.equalsIgnoreCase("q")) {
			System.out.println("\n You have exited search with policy number...\n");
		} else {
			String policyHolder  = searchHolder(policyNumber, 1);
			if (policyHolder == null) {
				System.out.println("\n================================================================================"
						+ "==========================================================================================");
				System.out.println("|                                                                         Policy "
						+ "Summary                                                                                 |");
				System.out.println("================================================================================="
						+ "=========================================================================================");
				System.out.format("%-15s%-35s%-15s%-35s%-20s%-20s%-20s%-10s", "Acct No.", "Acct. Holder", "Policy No.", 
						"Policy Holder", "Policy Premium", "Effective Date", "Expiration Date", "Status");
				System.out.println("\n================================================================================"
						+ "==========================================================================================");	
				System.out.println("\n No record found...");
				System.out.println("=================================================================================="
						+ "========================================================================================\n");
				policyNumber = null;
			} else {
				double policyPremium = searchPremium(policyNumber);
				searchAccount(policyNumber, policyHolder, policyPremium);
			}
		}
		return policyNumber;
	}
	
	public String inquirePolicy(String header) throws SQLException {
		PolicyHolder pHolder = new PolicyHolder();
		System.out.println(header);
		System.out.println("Enter 'q' if you want to quit.\n");
		String policyNumber = pHolder.enterString("Please enter policy number (XXXXXX): ", 6, 5);
		return policyNumber;
	}
	
	public void inquireWithClaimNumber() throws SQLException, ParseException {
		System.out.println("\n\n*******************Search by Claim Number*********************\n");
		boolean done = false;
		String claimNumber = null;
		int claimNum = 0;
		while (!done) {
			try {
				System.out.print("Please enter claim number you want to check (CXXXXX): ");
				claimNumber = scan.nextLine();
				if (claimNumber.charAt(0) != 'c' && claimNumber.charAt(0) != 'C') {
					System.out.println("Invalid input, please follow the format given (CXXXXX).");
				} else if (claimNumber.length() != 6) {
					System.out.println("Invalid input, please follow the format given (CXXXXX).");
				} else {
					claimNumber  = claimNumber.substring(1);
					claimNum = Integer.valueOf(claimNumber);
					done = true;
				}
			} catch (Exception e) {
				System.out.println(" Invalid input, please follow the format given (CXXXXX).");
			}
		}
		ResultSet rSet = select.selectClaim(claimNum);
		System.out.println("\n************************Claim Details*************************\n");
		searchClaim(rSet);
	}
}
